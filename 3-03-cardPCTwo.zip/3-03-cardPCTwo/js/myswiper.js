var mySwiper = new Swiper ('.swiper-container', {
            //direction: 'horizontal',
            direction: 'vertical',
            //需要指针手抓效果
            //grabCursor : true,
            //鼠标滚动控制
            mousewheelControl : true,
            // 如果需要前进后退按钮
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev'
        })