document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
				//WeixinJSBridge.call('hideToolbar');
				WeixinJSBridge.call('hideOptionMenu'); 
});
