/**
 * Created by Administrator on 2015/5/18.
 */
$(function(){

    //移动到了public.js里





});
