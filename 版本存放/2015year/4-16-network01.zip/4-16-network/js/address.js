/**
 * Created by Administrator on 2015/4/16.
 */
$(function(){

    //点击“查看光纤覆盖情况”按钮，显现相应内容
    $('.add-btn-ckgqfgqk').on('click',function(){
       $('.add-ul').show();
    });

});