/**
 * Created by Administrator on 2015/6/11.
 */
$(function(){
    //默认获取数组 1表示已打开，0表示未打开
    var gameNumber = [1,1,1,1,1,1,1,0];

    //载入调用粽子样式函数
    getGame(gameNumber);




});