/**
 * Created by Administrator on 2015/7/9.
 */
$(function(){
    $('.vo-time').on('click',function(){
        $(this).children('.vo-time-box')
            .addClass('vo-time-check');
        $(this).siblings()
            .children('.vo-time-box')
            .removeClass('vo-time-check');
    });
});