/**
 * Created by Administrator on 2015/4/10.
 */
$(function(){
   $('.gr-btn-hdgz').on('click',function(){
        $('.border-box').show();
        $('.index-zzc').show();
   });
});