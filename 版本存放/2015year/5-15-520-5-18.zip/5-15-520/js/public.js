/**
 * Created by Administrator on 2015/5/15.
 */
$(function(){

    //放大图片
    $('img.public-bg-img').on('click',function(){
        var thisSRC = $(this).attr('src');
        $('.public-bg-box').attr('src',thisSRC).show();
    });
    //点击隐藏图片
    $('.public-bg-box').on('click',function(){
        $(this).hide();
    });

    //输入框获取焦点
    $('.public-input').on('focus',function(){
        var thisDefault = $(this)[0].defaultValue;
        if($(this).val() == thisDefault)
        {
            $(this).val('');
        }
    });
    //输入框失去焦点
    $('.public-input').on('blur',function(){
        var thisDefault = $(this)[0].defaultValue;
        if($(this).val() == '')
        {
            $(this).val(thisDefault);
        }
    });


});