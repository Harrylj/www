$(function(){
	//点击选中状态
	$('.nh-list').on('click',function(){
		$(this).addClass('nh-click')
			.siblings()
			.removeClass('nh-click');
	})
})
