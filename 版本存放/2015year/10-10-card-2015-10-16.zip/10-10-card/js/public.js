$(function(){
	//alert(111);
	
	//点击"交易记录"，"赠送记录"，"充值记录"切换样式
	/*
	$('.up-btn').on('click',function(){
		var btnClick = 'up-btn-click';
		$(this).addClass(btnClick)
			.siblings()
			.removeClass(btnClick);
				
	})
	*/
	
	//点击切换按钮切换
	//thisClick:点击的按钮
	//thisChange:对应改变显示的地方
	//changeClass：点击的按钮改变的样式
	function clickToggle(thisClick,thisChange,changeClass){		
		var thClick= $(thisClick),
			thChange = $(thisChange),
			thClass = changeClass;
		thClick.on('click',function(){
			var thisIndex = $(this).index();
			$(this).addClass(thClass)
				.siblings()
				.removeClass(thClass);
			
			thChange.children()
				.eq(thisIndex)
				.show()
				.siblings()
				.hide();
		})
		
	}
	
	clickToggle('.this-click','.this-change','up-btn-click');
	/*
	$('.up-btn').on('click',function(){
		alert(1);
	})
	*/
	
})
