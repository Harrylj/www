$(function() {
	$.scrollUp();
});