var constant = {
	host : 'https://www.wxapp-gateway.com',
	path:{
		login:'/wxapp/login',
		getPaymentInfo:'/wxapp/getPaymentInfo',
		getUserInfo:'/wxapp/getUserInfo',
		saveUserInfo:'/wxapp/saveUserInfo',
		getSessionId:'/wxapp/getSessionId'
	}

};

module.exports = constant;