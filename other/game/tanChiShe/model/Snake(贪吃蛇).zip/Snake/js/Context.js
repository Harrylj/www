﻿function Context(context) {
    this.context = context;
}