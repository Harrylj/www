﻿function Parent(context, x, y, color) {
    Context.call(this, context);
    this.x = x;
    this.y = y;
    this.color = color;
}